package hackathon;

import hackathon.controller.TeamController;
import hackathon.model.TeamList;
import hackathon.view.HackathonFrame;

import javax.swing.*;
import java.io.IOException;

public class HackathonManager {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                TeamList list = new TeamList();
                TeamController controller = new TeamController(list);

                controller.loadTeams("HackathonTeams.csv");

                HackathonFrame frame = new HackathonFrame(controller);
                frame.setVisible(true);

            } catch (IOException e) {
                e.printStackTrace();
                System.exit(1);
            }
        });
    }
}

