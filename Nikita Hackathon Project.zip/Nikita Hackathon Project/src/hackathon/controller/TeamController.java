package hackathon.controller;

import hackathon.model.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public class TeamController {

    private TeamList teamList;

    public TeamController(TeamList teamList) {
        this.teamList = teamList;
    }

    public void loadTeams(String fileName) throws IOException {
        teamList.loadFromCsv(fileName);
    }

    public List<Team> getAllTeams() {
        return teamList.getAllTeams();
    }

    public Team findTeamById(int id) {
        return teamList.findTeamById(id);
    }

    public void removeTeam(int id) {
        teamList.removeTeam(id);
    }

    public List<Team> getTeamsByCategory(String catName) {
        return teamList.getTeamsByCategoryName(catName);
    }

    public List<Team> getTeamsSortedByOverall() {
        return teamList.getTeamsSortedByOverallDesc();
    }

    public double getAverageScore() {
        return teamList.getAverageOverallScore();
    }

    public Map<Integer, Integer> getScoreFrequency() {
        return teamList.getScoreFrequency();
    }

    public void saveReport(String filename) throws IOException {
        teamList.writeReport(filename);
    }
}
