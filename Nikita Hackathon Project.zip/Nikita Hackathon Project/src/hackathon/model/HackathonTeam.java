package hackathon.model;

import java.util.Arrays;

public class HackathonTeam extends Team {

    public HackathonTeam(int teamId, Name teamName, Category category,
                         String institution, String state, int[] scores) {
        super(teamId, teamName, category, institution, state, scores);
    }

    @Override
    public double getOverallScore() {
        if (scores == null || scores.length == 0) return 0;

        int[] sorted = Arrays.copyOf(scores, scores.length);
        Arrays.sort(sorted);

        if (sorted.length > 2) {
            int sum = 0;
            for (int i = 1; i < sorted.length - 1; i++) {
                sum += sorted[i];
            }
            return sum / (double) (sorted.length - 2);
        } else {
            int sum = 0;
            for (int s : sorted) sum += s;
            return sum / (double) sorted.length;
        }
    }
}

