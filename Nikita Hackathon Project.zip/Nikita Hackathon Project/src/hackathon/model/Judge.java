package hackathon.model;

import java.util.List;

public class Judge {
    private int judgeId;
    private Name judgeName;
    private List<Category> categories;

    public Judge(int judgeId, Name judgeName, List<Category> categories) {
        this.judgeId = judgeId;
        this.judgeName = judgeName;
        this.categories = categories;
    }

    public int getJudgeId() { return judgeId; }
    public Name getJudgeName() { return judgeName; }
    public List<Category> getCategories() { return categories; }

    @Override
    public String toString() {
        return judgeName.getDisplayName();
    }
}
