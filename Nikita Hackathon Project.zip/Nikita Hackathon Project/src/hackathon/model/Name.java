package hackathon.model;

public class Name {
    private String firstName;
    private String middleName;
    private String lastName;

    public Name(String firstName, String middleName, String lastName) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
    }

    public String getFirstName() { return firstName; }
    public String getMiddleName() { return middleName; }
    public String getLastName() { return lastName; }

    public String getInitials() {
        StringBuilder sb = new StringBuilder();
        if (!firstName.isEmpty()) sb.append(firstName.charAt(0));
        if (!lastName.isEmpty()) sb.append(lastName.charAt(0));
        return sb.toString().toUpperCase();
    }

    public String getDisplayName() {
        if (middleName == null || middleName.isEmpty()) {
            return firstName + " " + lastName;
        }
        return firstName + " " + middleName + " " + lastName;
    }

    @Override
    public String toString() { return getDisplayName(); }
}
