package hackathon.model;

public class ProHackathonTeam extends Team {

    public ProHackathonTeam(int teamId, Name teamName, Category category,
                            String institution, String state, int[] scores) {
        super(teamId, teamName, category, institution, state, scores);
    }

    @Override
    public double getOverallScore() {
        if (scores == null || scores.length == 0) return 0;

        double total = 0;
        double weightSum = 0;

        for (int i = 0; i < scores.length; i++) {
            double weight = 1 + (i * 0.2);
            total += scores[i] * weight;
            weightSum += weight;
        }

        return total / weightSum;
    }
}

