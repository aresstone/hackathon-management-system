package hackathon.model;

public class Score {
    private int creativity;
    private int technical;
    private int innovation;
    private int presentation;

    public Score(int creativity, int technical, int innovation, int presentation) {
        this.creativity = creativity;
        this.technical = technical;
        this.innovation = innovation;
        this.presentation = presentation;
    }

    public int[] toArray() {
        return new int[]{creativity, technical, innovation, presentation};
    }
}
