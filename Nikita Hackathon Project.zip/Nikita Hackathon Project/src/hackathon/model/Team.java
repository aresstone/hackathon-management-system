package hackathon.model;

import java.util.Arrays;

public abstract class Team {

    protected int teamId;
    protected Name teamName;
    protected Category category;
    protected String institution;
    protected String state;
    protected int[] scores;

    public Team(int teamId, Name teamName, Category category,
                String institution, String state, int[] scores) {
        this.teamId = teamId;
        this.teamName = teamName;
        this.category = category;
        this.institution = institution;
        this.state = state;
        this.scores = scores;
    }

    public Team(int teamId, Name teamName, Category category,
                String institution, String state) {
        this(teamId, teamName, category, institution, state, new int[0]);
    }

    public int getTeamId() { return teamId; }
    public Name getTeamName() { return teamName; }
    public Category getCategory() { return category; }
    public String getInstitution() { return institution; }
    public String getState() { return state; }

    public int[] getScoreArray() {
        return Arrays.copyOf(scores, scores.length);
    }

    public void setScores(int[] newScores) {
        this.scores = Arrays.copyOf(newScores, newScores.length);
    }

    public abstract double getOverallScore();

    public String getFullDetails() {
        StringBuilder sb = new StringBuilder();
        sb.append("Team ID ").append(teamId)
                .append(", name ").append(teamName.getDisplayName())
                .append(" (").append(institution)
                .append("). ").append(teamName.getDisplayName())
                .append(" is competing in the ")
                .append(category.getCategoryName())
                .append(" category");

        if (scores != null && scores.length > 0) {
            sb.append(" and received scores ")
                    .append(Arrays.toString(scores))
                    .append(", resulting in an overall score of ")
                    .append(String.format("%.2f", getOverallScore()));
        } else {
            sb.append(" and has not yet received any scores.");
        }

        return sb.toString();
    }

    public String getShortDetails() {
        return String.format("TID %d (%s) has an overall score of %.2f",
                teamId, teamName.getInitials(), getOverallScore());
    }

    @Override
    public String toString() {
        return getShortDetails();
    }
}
