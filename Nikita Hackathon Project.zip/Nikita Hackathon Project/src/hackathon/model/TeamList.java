package hackathon.model;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class TeamList {

    private List<Team> teams = new ArrayList<>();

    public void loadFromCsv(String filename) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(filename));

        for (String line : lines) {
            if (line.trim().isEmpty() || line.startsWith("#")) continue;

            try {
                String[] p = line.split(",");

                int id = Integer.parseInt(p[0]);
                Name name = new Name(p[1], "", p[2]);
                String institution = p[3];
                String state = p[4];

                int catId = Integer.parseInt(p[5]);
                String catName = p[6];
                String desc = p[7];
                Category category = new Category(catId, catName, desc);

                String type = p[8];
                boolean isPro = Boolean.parseBoolean(p[9]);

                int[] scores = new int[]{
                        Integer.parseInt(p[10]),
                        Integer.parseInt(p[11]),
                        Integer.parseInt(p[12]),
                        Integer.parseInt(p[13]),
                        Integer.parseInt(p[14])
                };

                Team team;
                if (isPro) {
                    team = new ProHackathonTeam(id, name, category, institution, state, scores);
                } else {
                    team = new HackathonTeam(id, name, category, institution, state, scores);
                }

                teams.add(team);

            } catch (Exception e) {
                System.out.println("Skipping bad line: " + line);
            }
        }
    }

    public List<Team> getAllTeams() {
        return new ArrayList<>(teams);
    }

    public Team findTeamById(int id) {
        for (Team t : teams) {
            if (t.getTeamId() == id) return t;
        }
        return null;
    }

    public void removeTeam(int id) {
        teams.removeIf(t -> t.getTeamId() == id);
    }

    public List<Team> getTeamsByCategoryName(String name) {
        List<Team> list = new ArrayList<>();
        for (Team t : teams) {
            if (t.getCategory().getCategoryName().equalsIgnoreCase(name)) {
                list.add(t);
            }
        }
        return list;
    }

    public List<Team> getTeamsSortedByOverallDesc() {
        List<Team> copy = new ArrayList<>(teams);
        copy.sort((a, b) -> Double.compare(b.getOverallScore(), a.getOverallScore()));
        return copy;
    }

    public double getAverageOverallScore() {
        double total = 0;
        for (Team t : teams) total += t.getOverallScore();
        return teams.isEmpty() ? 0 : total / teams.size();
    }

    public Map<Integer, Integer> getScoreFrequency() {
        Map<Integer, Integer> freq = new TreeMap<>();
        for (int i = 0; i <= 5; i++) freq.put(i, 0);

        for (Team t : teams) {
            for (int s : t.getScoreArray()) {
                freq.put(s, freq.get(s) + 1);
            }
        }
        return freq;
    }

    public void writeReport(String filename) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(filename));

        writer.write("=== Hackathon Report ===\n\n");

        for (Team t : teams) {
            writer.write(t.getFullDetails() + "\n\n");
        }

        writer.write("Top Team: " + getTeamsSortedByOverallDesc().get(0).getShortDetails() + "\n");
        writer.write("Average Score: " + String.format("%.2f", getAverageOverallScore()) + "\n");
        writer.write("Score Frequency: " + getScoreFrequency() + "\n");

        writer.close();
    }
}
