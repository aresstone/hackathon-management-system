package hackathon.model;

public class TeamMember {
    private int memberId;
    private Name memberName;

    public TeamMember(int memberId, Name memberName) {
        this.memberId = memberId;
        this.memberName = memberName;
    }

    public int getMemberId() { return memberId; }
    public Name getMemberName() { return memberName; }

    @Override
    public String toString() {
        return memberName.getDisplayName();
    }
}
