package hackathon.view;

import hackathon.controller.TeamController;
import hackathon.model.Team;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.List;

public class HackathonFrame extends JFrame {

    private TeamController controller;

    private JComboBox<Integer> teamIdCombo;
    private JTextArea detailsArea;
    private JTextField filterField;
    private JTable teamTable;
    private JTextField scoreField;
    private JLabel overallLabel;

    public HackathonFrame(TeamController controller) {
        this.controller = controller;

        setTitle("Hackathon Management System");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        add(createTopPanel(), BorderLayout.NORTH);
        add(createCenterPanel(), BorderLayout.CENTER);
        add(createBottomPanel(), BorderLayout.SOUTH);

        refreshTeamCombo();
        refreshTable(controller.getAllTeams());
    }

    private JPanel createTopPanel() {
        JPanel panel = new JPanel();

        panel.add(new JLabel("Team ID:"));
        teamIdCombo = new JComboBox<>();
        panel.add(teamIdCombo);

        JButton viewBtn = new JButton("View Details");
        viewBtn.addActionListener(e -> viewSelectedTeam());
        panel.add(viewBtn);

        return panel;
    }

    private JPanel createCenterPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 2));

        detailsArea = new JTextArea();
        detailsArea.setEditable(false);
        panel.add(new JScrollPane(detailsArea));

        teamTable = new JTable();
        panel.add(new JScrollPane(teamTable));

        return panel;
    }

    private JPanel createBottomPanel() {
        JPanel panel = new JPanel();

        panel.add(new JLabel("Filter by Category:"));
        filterField = new JTextField(10);
        panel.add(filterField);

        JButton filterBtn = new JButton("Filter");
        filterBtn.addActionListener(e -> filterTeams());
        panel.add(filterBtn);

        JButton allBtn = new JButton("Reset");
        allBtn.addActionListener(e -> refreshTable(controller.getAllTeams()));
        panel.add(allBtn);

        panel.add(new JLabel("Scores (comma-separated):"));
        scoreField = new JTextField(12);
        panel.add(scoreField);

        JButton updateBtn = new JButton("Update Scores");
        updateBtn.addActionListener(e -> updateScores());
        panel.add(updateBtn);

        JButton removeBtn = new JButton("Remove Team");
        removeBtn.addActionListener(e -> removeTeam());
        panel.add(removeBtn);

        overallLabel = new JLabel("Overall Score: 0.00");
        panel.add(overallLabel);

        JButton exitBtn = new JButton("Save Report & Exit");
        exitBtn.addActionListener(this::exitAndSave);
        panel.add(exitBtn);

        return panel;
    }

    private void refreshTeamCombo() {
        teamIdCombo.removeAllItems();
        for (Team t : controller.getAllTeams()) {
            teamIdCombo.addItem(t.getTeamId());
        }
    }

    private void refreshTable(List<Team> teams) {
        String[] cols = { "ID", "Name", "Category", "Institution", "Overall" };
        DefaultTableModel model = new DefaultTableModel(cols, 0);

        for (Team t : teams) {
            model.addRow(new Object[]{
                    t.getTeamId(),
                    t.getTeamName().getDisplayName(),
                    t.getCategory().getCategoryName(),
                    t.getInstitution(),
                    String.format("%.2f", t.getOverallScore())
            });
        }

        teamTable.setModel(model);
    }

    private void viewSelectedTeam() {
        Integer id = (Integer) teamIdCombo.getSelectedItem();
        if (id == null) return;

        Team t = controller.findTeamById(id);
        if (t != null) {
            detailsArea.setText(t.getFullDetails());
            overallLabel.setText("Overall Score: " + String.format("%.2f", t.getOverallScore()));
        }
    }

    private void filterTeams() {
        String cat = filterField.getText().trim();
        if (cat.isEmpty()) return;

        refreshTable(controller.getTeamsByCategory(cat));
    }

    private void updateScores() {
        Integer id = (Integer) teamIdCombo.getSelectedItem();
        if (id == null) return;

        String[] parts = scoreField.getText().split(",");
        try {
            int[] scores = new int[parts.length];
            for (int i = 0; i < parts.length; i++) {
                scores[i] = Integer.parseInt(parts[i].trim());
            }

            Team t = controller.findTeamById(id);
            t.setScores(scores);

            viewSelectedTeam();
            refreshTable(controller.getAllTeams());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid score format.");
        }
    }

    private void removeTeam() {
        Integer id = (Integer) teamIdCombo.getSelectedItem();
        if (id == null) return;

        controller.removeTeam(id);
        refreshTeamCombo();
        refreshTable(controller.getAllTeams());
        detailsArea.setText("");
        overallLabel.setText("Overall Score: 0.00");
    }

    private void exitAndSave(ActionEvent e) {
        try {
            controller.saveReport("HackathonReport.txt");
            JOptionPane.showMessageDialog(this, "Report saved. Exiting.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving report.");
        }
        System.exit(0);
    }
}

